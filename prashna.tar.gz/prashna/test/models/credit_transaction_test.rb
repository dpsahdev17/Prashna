require 'test_helper'

class CreditTransactionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
