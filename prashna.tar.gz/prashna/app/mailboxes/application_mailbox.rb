class ApplicationMailbox < ActionMailbox::Base
  # routing /something/i => :somewhere
end
