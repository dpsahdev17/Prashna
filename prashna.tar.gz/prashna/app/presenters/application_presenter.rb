class ApplicationPresenter < BasicPresenter::BasePresenter
  ## Shared Methods might come here
end
