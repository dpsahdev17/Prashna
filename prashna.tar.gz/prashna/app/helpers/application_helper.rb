module ApplicationHelper
  #done FIXME_AB: read https://github.com/vinsol/basic_presenter and lets try to make a question presentor
  #done FIXME_AB: question.markdown_text
end

